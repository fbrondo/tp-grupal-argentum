#pragma once

#include "server/includes/commands/command.h"

class BuyItemCommand: public Command {
private:
    Id npc_id;
    Id item_id;

public:
    BuyItemCommand(Id id, Id npc_id, Id item_id);
    void execute(Gameloop& game) override;
};
