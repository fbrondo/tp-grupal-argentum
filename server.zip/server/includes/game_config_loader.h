#ifndef GAME_CONFIG_LOADER_H
#define GAME_CONFIG_LOADER_H

#include <filesystem>
#include <map>
#include <memory>
#include <string>
#include <unordered_map>

#include <toml++/toml.hpp>

#include "server/includes/core/config.h"
#include "server/includes/core/item.h"
#include "server/includes/core/race.h"
#include "server/includes/core/region.h"
#include "server/includes/definitions.h"

using Table = toml::table;
using Table_array = toml::array;

class GameConfigLoader {
private:
    static constexpr const char* FILE_PATHS = "paths.toml";
    const Path config_dir;
    PathsConfig paths;
    FileData data;

    void loadPaths();
    Path loadPath(const Table& config, const std::string& section_key,
                  const std::string& fiel_key) const;

    Statistics loadTableStatistics(Table_array* stats_array);

    void loadCreatures(std::map<std::string, CreatureConfig>& creatures);
    void loadNpcSafeZone(std::map<std::string, NpcSafeZone>& npcs);
    void loadRaces(std::map<TypeRace, Race>& info_races);
    void loadClases(std::map<TypeClase, Clase>& info_clases);
    void loadItems(std::map<TypeItem, std::unique_ptr<Item>>& info_items);
    void loadRegions(std::map<Region, std::unique_ptr<RegionWorld>>& info_regions);
    void loadGame(PlayerStateInit& player_init, ClanConfig& clan, TimesConfig& times);

public:
    GameConfigLoader(const GameConfigLoader& other) = delete;
    GameConfigLoader& operator=(const GameConfigLoader& other) = delete;

    explicit GameConfigLoader(Path config_dir_);

    const FileData getFilesData();
    GameConfig getdGameConfiguration();
};


#endif
